<?php
// Initialize the session
session_start();
 
// Check if the user is logged in, if not then redirect him to login page
if(!isset($_SESSION["loggedin"]) || $_SESSION["loggedin"] !== true){
    header("location: login.php");
    exit;
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Welcome</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{ 
            text-align: center;
            background-image: url('default.jpg');
            background-repeat: no-repeat;
            background-attachment: fixed;
            background-size: cover;  
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .center{
            background-image: url('images.png');
            position: center;
            margin:auto;
            width: 400px;            
            border: 3px solid #66a3ff;
            padding: 30px;
        }
        h1{
            font: 50px Georgia, serif; 
            text-align: center;
            text-transform: capitalize;
            text-shadow: 2px 2px 2px #248f8f,
             2px 2px 1px #248f8f;

        }
        h4{
            font: 20px Snell Roundhand, cursive;
           
        }
        * {
            -webkit-box-sizing: border-box;
            -moz-box-sizing: border-box;
            box-sizing: border-box;
        }
        hr{
            
            border-top: 1px dashed #248f8f;
        }
        .buttons {
            margin: 10%;
            text-align: center;
        }

        .btn-hover {
            width: 200px;
            font-size: 16px;
            font-weight: 600;
            color: #fff;
            cursor: pointer;
            margin: 20px;
            height: 55px;
            text-align:center;
            border: none;
            background-size: 300% 100%;

            border-radius: 50px;
            moz-transition: all .4s ease-in-out;
            -o-transition: all .4s ease-in-out;
            -webkit-transition: all .4s ease-in-out;
            transition: all .4s ease-in-out;
        }

        .btn-hover:hover {
            background-position: 100% 0;
            moz-transition: all .4s ease-in-out;
            -o-transition: all .4s ease-in-out;
            -webkit-transition: all .4s ease-in-out;
            transition: all .4s ease-in-out;
        }

        .btn-hover:focus {
            outline: none;
        }


        .btn-hover.color-9 {
            background-image: linear-gradient(to right, #25aae1, #4481eb, #04befe, #3f86ed);
            box-shadow: 0 4px 15px 0 rgba(65, 132, 234, 0.75);
        }


    </style>
</head>
<body>
    <div class="center">
        <h1>Buna, <b><?php echo htmlspecialchars($_SESSION["username"]); ?></b></h1>
        <hr/>
        <h4><i>Bine ai venit pe acest site!<i></h4>
        <hr/>
        <br>
        <div>
        <form action="meniu1.php">    
            <button type="submit" class="btn-hover color-9">Intra in meniul principal</button>
        </form>
        </div> 
        <br>
        
        <div>
        <form action="reset-password.php">
            <button type="submit" class="btn-hover color-9" >Reseteaza parola</button>
        </form>
        <br>
        
        <form action="logout.php">
            <button type="submit" class="btn-hover color-9">Delogare</button>
        </form>
        
   
    </div>
       
</body>
</html>