<html>
	<head>
		<?php include('templates/header.php');?>
		<style type="text/css">
			body{
				background-image: url('grey.jpg');
			    text-align: center;
			  	font-family: Georgia, serif;
			  	margin: 25px;
		  	}
		  	div.polaroid {
  				width: 40%;
  				margin:auto;
  				background-color: white;
  				box-shadow: 0 4px 8px 0 rgba(0, 0, 0, 0.2), 0 6px 20px 0 rgba(0, 0, 0, 0.19);
  				margin-bottom: 25px;
			}

			div.container {
				
  				background-color: #ffffff;
			  	text-align: center;
			  	padding: 10px 20px;
			  	border: 1px solid black;
  				opacity: 0.6;
			}
			div.container p{
				align-items: center;
		  		color:#e0c1f7;
		  		font-weight:100;
		  		font-size:25px;
			}	
		</style>
	</head>
	<body>
		<div class="polaroid">
		  <img src="sediucluj.jpg" alt="5 Terre" style="width:100%">
		</div>
		<div class="container">
			<p>Sediul din Cluj se afla intr-o zona centrala, aproape de cladirea X si cu o priveliste impresionanta spre Y.</p>
		</div><br>
		<div class="polaroid">
		  <img src="sediubuc.jpg" alt="5 Terre" style="width:100%">
		</div>
		<div class="container">
			<p>Sediul din Bucuresti se afla intr-o zona centrala, aproape de cladirea X si cu o priveliste impresionanta spre Y.</p>
		</div><br>
		<div class="polaroid">
		  <img src="sediucon.jpg" alt="5 Terre" style="width:100%">
		</div>
		<div class="container">
			<p>Sediul din Constanta se afla intr-o zona periferica, aproape de cladirea X si cu o priveliste impresionanta spre Y.</p>
		</div><br>
		<div class="polaroid">
		  <img src="sediutim.jpg" alt="5 Terre" style="width:100%">
		</div>
		<div class="container">
			<p>Sediul din Timisoara se afla intr-o zona periferica, aproape de cladirea X si cu o priveliste impresionanta spre Y.</p>
		</div><br>
	</body>
	<?php include('templates/footer.php');?>
</html>