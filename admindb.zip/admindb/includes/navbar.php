<div class="navbar">
	<div class="logo_div">
		<a href="index.php"><h1>Login page</h1></a>
	</div>
</div>