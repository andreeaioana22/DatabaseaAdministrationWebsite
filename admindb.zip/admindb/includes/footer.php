	<div class="footer">
			
		</div>
	</div>
	<!-- // container -->
</body>
</html>