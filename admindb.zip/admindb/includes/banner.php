<div class="banner">
	<div class="welcome_msg">
		<h1>Sistem de administrare baze de date</h1>

	</div>
	<div class="login_div">
		<form action="login.php" method="post" >
			<h2>Login</h2>
			<input type="text" name="username" placeholder="Username">
			<input type="password" name="password"  placeholder="Password"> 
			<button class="btn" type="submit" name="login_btn">Sign in</button>
		</form>
	</div>
</div>