<?php
?>
<!DOCTYPE html>
<html lang="en">
<head>
	  <?php include('templates/header1.php');?>
	<style type="text/css">
		* {
			-webkit-transition-property: all;
			-webkit-transition-duration: .2s;
		  	-moz-transition-timing-function: cubic-bezier(100,50,21,6);
			-moz-transition-property: all;
		  	-moz-transition-timing-function: cubic-bezier(100,50,21,6);
		}

		body{
		    text-align: center;
		  	font-family: Georgia, serif;
		  	background-color:rgba(0, 0, 0, 0.61);
		}

		p{
		  align-items: center;
		  color:#fff;
		  font-weight:100;
		  font-size:25px;

		}

		.btn{
		  color:#fff;
		  background:rgba(199, 165, 243, 1);
		  padding:10px 20px;
		  font-size:12px;
		  text-decoration:none;
		  letter-spacing:2px;
		  text-transform:uppercase;
		}

		.btn:hover{
		  border:none;
		  background:rgba(0, 0, 0, 0.4);
		  background:#fff;
		  padding:20px 20px; #000;
		  color:#1b1b1b;
		}

		.footer{
		  font-size:8px;
		  color:#fff;
		  clear:both;
		  display:block;
		  letter-spacing:5px;
		  border:1px solid #fff;
		  padding:5px;
		  text-decoration:none;
		  width:210px;
		  margin:auto;
		  margin-top:400px;
		}		
	</style>
</head>

 <body>
	
	<link href='https://fonts.googleapis.com/css?family=Oswald:300' rel='stylesheet' type='text/css'>
	<br>
	
    <p>Tabelul client: </p>
    
    <a href="viewclientbuc.php" class="btn">Vizualizare</a>
    <a href="addclientbuc.php" class="btn">Adaugare</a>
    <a href="modifyclientbuc.php" class="btn">Modificare/Stergere</a>

    <br>
    <br>
    <p>Tabelul produse: </p>
    
    <a href="viewprodbuc.php" class="btn">Vizualizare</a>
    <a href="addprodbuc.php" class="btn">Adaugare</a>
    <a href="modifyprodbuc.php" class="btn">Modificare/Stergere</a>

    <br>
    <br>
    <p>Tabelul angajat: </p>
    
    <a href="viewangbuc.php" class="btn">Vizualizare</a>
    <a href="addangbuc.php" class="btn">Adaugare</a>
    <a href="modifyangbuc.php" class="btn">Modificare/Stergere</a>

    <br>
    <br>
    <p>Tabelul departament: </p>
    
    <a href="viewdepbuc.php" class="btn">Vizualizare</a>
    <a href="adddepbuc.php" class="btn">Adaugare</a>
    <a href="modifydepbuc.php" class="btn">Modificare/Stergere</a><br>

    <br>

    <?php include('templates/footer.php');?>
</body>
  
</html>