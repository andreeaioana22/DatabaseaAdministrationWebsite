<?php
	

	// Process delete operation after confirmation
	if(isset($_POST["id"]) && !empty($_POST["id"])){
    // Include config file
    $servername = "localhost";
	$username = "andreea";
	$password = "test1234";
	$dbname = "constanta";

	// Create connection
	$dbh4 = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($dbh4->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
	}
    
    // Prepare a delete statement
    $sql = "DELETE FROM produse WHERE id = ?";
    
    if($stmt = mysqli_prepare($dbh4, $sql)){
        // Bind variables to the prepared statement as parameters
        mysqli_stmt_bind_param($stmt, "i", $param_id);
        
        // Set parameters
        $param_id = trim($_POST["id"]);
        
        // Attempt to execute the prepared statement
        if(mysqli_stmt_execute($stmt)){
            // Records deleted successfully. Redirect to landing page
            header("location: viewprodcons.php");
            exit();
        } else{
            echo "Oops! Something went wrong. Please try again later.";
        }
    }
     
    // Close statement
    mysqli_stmt_close($stmt);
    
    // Close connection
    mysqli_close($dbh4);
} else{
    // Check existence of id parameter
    if(empty(trim($_GET["id"]))){
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>View Record</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.css">
    <style type="text/css">
        body{

			background-image: url('grey.jpg');
		    text-align: center;
		  	font-family: Georgia, serif;
		  	
		}
		.wrapper{ 
            width: 350px; 
            padding: 20px; 
            text-align: center;
            justify-content: center;
            margin-top: 80px; 
            margin-left: 600px; 
            background-image: url('images.png');
            -moz-box-shadow: 0 0 20px #bd80ff;
            -webkit-box-shadow: 0 0 20px #bd80ff;
            box-shadow: 0px 0px 20px #bd80ff;
            }
            .btn{
			color:#aea0f3;
			background-color:#fff;
			outline: none;
		    border: 3px;
		    font-weight: bold;
			padding:10px 20px;
			text-transform:uppercase;
			margin-top:50px;
			border-radius:2px;
			cursor:pointer;
			position:relative;
		}

    </style>
</head>
<body>

    <div class="wrapper">
        <div class="container-fluid">
            <div class="row">
                <div class="col-md-12">
                    <div class="page-header">
                        <h3>Sterge o inregistrare</h3>
                    </div>
                    <form action="<?php echo htmlspecialchars($_SERVER["PHP_SELF"]); ?>" method="post">
                        <div class="alert alert-danger fade in">
                            <input type="hidden" name="id" value="<?php echo trim($_GET["id"]); ?>"/>
                            <p>Esti sigur ca doresti sa stergi aceasta inregistrare?</p><br>
                            <p>
                                <input type="submit" value="Yes" class="btn ">
                                <a href="modifyprodcons.php" class="btn ">No</a>
                            </p>
                        </div>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>