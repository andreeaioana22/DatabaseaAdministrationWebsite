<!DOCTYPE html>
<html lang="en">
<head>
<style type="text/css">

        body{

            background-image: url('grey.jpg');
            text-align: center;
            font-family: Georgia, serif;
            
        }

        .btn{
            color:#aea0f3;
            background-color:#fff;
            outline: none;
            border: 3px;
            font-weight: bold;
            padding:10px 20px;
            text-transform:uppercase;
            margin-top:50px;
            border-radius:2px;
            cursor:pointer;
            position:relative;
        }
        /*.btn:after{
            content:"";
            position:absolute;
            background:rgba(0,0,0,0.50);
            top:0;
            right:0;
            width:100%;
            height:100%;
        }*/
        div.transbox {
          margin: 50px 200px 200px 200px;
          background-color: #ffffff;
          border: 1px solid black;
          opacity: 0.7;
          box-shadow: 10px 10px 8px #888888;
        }
        table {
        color: #7070db;
        font-family: Georgia, serif;
        text-align: left;
        font-size: 20px;
        }
        th {
        background-color: #7070db;
        color: white;
        padding: 15px;
        text-align: left;
        }
        tr:nth-child(even) {background-color: #c2c2f0;}
        
</style>
    <script type="text/javascript">
        $(document).ready(function(){
            $('[data-toggle="tooltip"]').tooltip();   
        });
    </script>
</head>
<body>
    <?php include('templates/header5.php');?>
    <div class="transbox">
        <div >
            <div>
                <div>

                    <?php
                           
                        $servername = "localhost";
                        $username = "andreea";
                        $password = "test1234";
                        $dbname = "constanta";

                        // Create connection
                        $dbh4 = new mysqli($servername, $username, $password, $dbname);
                        // Check connection
                        if ($dbh4->connect_error) {
                          die("Connection failed: " . $conn->connect_error);
                        }
                    
                    // Attempt select query execution
                    $sql = "SELECT * FROM departamente";
                    if($result = mysqli_query($dbh4, $sql)){
                        if(mysqli_num_rows($result) > 0){
                            echo "<table class='table'>";
                                echo "<thead>";
                                    echo "<tr>";
                                        echo "<th>id</th>";
                                        echo "<th>nume</th>";
                                        echo "<th>manager</th>";
                                        echo "<th>numarAngajati</th>";
                                        echo "<th>modifica/sterge</th>";
                                    echo "</tr>";
                                echo "</thead>";
                                echo "<tbody>";
                                while($row = mysqli_fetch_array($result)){
                                    echo "<tr>";
                                        echo "<td>" . $row['id'] . "</td>";
                                        echo "<td>" . $row['nume'] . "</td>";
                                        echo "<td>" . $row['manager'] . "</td>";
                                        echo "<td>" . $row['numarAngajati'] . "</td>";
                                        
                                        echo "<td>";
                                            echo "<a href='modifydepcons1.php?id=". $row['id'] ."' title='Update Record' data-toggle='tooltip'><span class='glyphicon glyphicon-star-empty'></span></a>";
                                            echo"   /  ";
                                            echo "<a href='deletedepcons.php?id=". $row['id'] ."' title='Delete Record' data-toggle='tooltip'><span class='glyphicon glyphicon-trash'></span></a>";
                                        echo "</td>";
                                    echo "</tr>";
                                }
                                echo "</tbody>";                            
                            echo "</table>";
                            // Free result set
                            mysqli_free_result($result);
                        } else{
                            echo "<p class='lead'><em>No records were found.</em></p>";
                        }
                    } else{
                        echo "ERROR: Could not able to execute $sql. " . mysqli_error($dbh4);
                    }
 
                    // Close connection
                    mysqli_close($dbh4);
                    ?>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>