<!DOCTYPE html>
<html>
<head>
<style type="text/css">

		body{

			background-image: url('grey.jpg');
		    text-align: center;
		  	font-family: Georgia, serif;
		  	
		}
		.btn{
			color:#aea0f3;
			background-color:#fff;
			outline: none;
		    border: 3px;
		    font-weight: bold;
			padding:10px 20px;
			text-transform:uppercase;
			margin-top:50px;
			border-radius:2px;
			cursor:pointer;
			position:relative;
		}
		/*.btn:after{
			content:"";
			position:absolute;
			background:rgba(0,0,0,0.50);
			top:0;
			right:0;
			width:100%;
			height:100%;
		}*/
		div.transbox {
  		  margin: 50px 200px 200px 200px;
		  background-color: #ffffff;
		  border: 1px solid black;
		  opacity: 0.7;
		  box-shadow: 10px 10px 8px #888888;
		}
		table {
		color: #7070db;
		font-family: Georgia, serif;
		text-align: left;
		font-size: 20px;
		}
		th {
		background-color: #7070db;
		color: white;
		padding: 15px;
  		text-align: left;
		}
		tr:nth-child(even) {background-color: #c2c2f0;}

</style>
</head>
<body>
	<?php include('templates/header1.php');?>
	<div class="transbox">	
		<table class="table">
			<tr>
			<th>id</th>
			<th>nume</th>
			<th>manager</th>
			<th>numarAngajati</th>
			</tr>
				<?php
					$conn = mysqli_connect("localhost", "andreea", "test1234", "bucuresti");
				// Check connection
				if ($conn->connect_error) {
				die("Connection failed: " . $conn->connect_error);
				}
				$sql = "SELECT id,nume,manager,numarAngajati FROM departamente";
				$result = $conn->query($sql);
				if ($result->num_rows > 0) {
				// output data of each row
				while($row = $result->fetch_assoc()) {
				echo "<tr><td>" . $row["id"]. "</td><td>" . $row["nume"] . "</td><td>"
				. $row["manager"]. "</td><td>". $row["numarAngajati"] . "</td></tr>";
				}
				echo "</table>";
				} else { echo "0 results"; }
				$conn->close();
				?>
		</table>
	</div>
</body>
</html>