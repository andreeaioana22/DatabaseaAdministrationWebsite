<?php
// Include config file
   
$servername = "localhost";
$username = "andreea";
$password = "test1234";
$dbname = "timisoara";

// Create connection
$dbh3 = new mysqli($servername, $username, $password, $dbname);
// Check connection
if ($dbh3->connect_error) {
die("Connection failed: " . $conn->connect_error);
}
                    
 
// Define variables and initialize with empty values
$nume = $manager = $numarAngajati = "";
$nume_err = $manager_err = $numarAngajati_err = "";
 
// Processing form data when form is submitted
if(isset($_POST["id"]) && !empty($_POST["id"])){
    // Get hidden input value
    $id = $_POST["id"];
    
    // Validate name
    $input_nume = trim($_POST["nume"]);
    if(empty($input_nume)){
        $nume_err = "Please enter a name.";
    } elseif(!filter_var($input_nume, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
        $nume_err = "Please enter a valid name.";
    } else{
        $nume = $input_nume;
    }
    
    // Validate address address
    $input_manager = trim($_POST["manager"]);
    if(empty($input_manager)){
        $manager_err = "Please enter a name.";
    } elseif(!filter_var($input_manager, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[a-zA-Z\s]+$/")))){
        $manager_err = "Please enter a valid name.";
    } else{
        $manager = $input_manager;
    }
    // Validate salary
    $input_numarAngajati = trim($_POST["numarAngajati"]);
    if(empty($input_numarAngajati)){
        $numarAngajati_err = "telefonul trebuie completat!";     
    } elseif(!filter_var($input_numarAngajati, FILTER_VALIDATE_REGEXP, array("options"=>array("regexp"=>"/^[0-9]*$/")))){
        $numarAngajati_err = "Please enter a valid name.";
    } else{
        $numarAngajati = $input_numarAngajati;
    }
    
    // Check input errors before inserting in database
    if(empty($nume_err) && empty($manager_err) && empty($numarAngajati_err)){
        // Prepare an update statement
        $sql = "UPDATE departamente SET nume=?, manager=?, numarAngajati=? WHERE id=?";
         
        if($stmt = mysqli_prepare($dbh3, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "sssi", $param_nume, $param_manager, $param_numarAngajati, $param_id);
            
            // Set parameters
            $param_nume = $nume;
            $param_manager = $manager;
            $param_numarAngajati = $numarAngajati;
            $param_id = $id;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Records updated successfully. Redirect to landing page
                header("location: viewdeptim.php");
                exit();
            } else{
                echo "Something went wrong. Please try again later.";
            }
        }
         
        // Close statement
        mysqli_stmt_close($stmt);
    }
    
    // Close connection
    mysqli_close($dbh3);
} else{
    // Check existence of id parameter before processing further
    if(isset($_GET["id"]) && !empty(trim($_GET["id"]))){
        // Get URL parameter
        $id =  trim($_GET["id"]);
        
        // Prepare a select statement
        $sql = "SELECT * FROM departamente WHERE id = ?";
        if($stmt = mysqli_prepare($dbh3, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "i", $param_id);
            
            // Set parameters
            $param_id = $id;
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                $result = mysqli_stmt_get_result($stmt);
    
                if(mysqli_num_rows($result) == 1){
                    /* Fetch result row as an associative array. Since the result set contains only one row, we don't need to use while loop */
                    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);
                    
                    // Retrieve individual field value
                    $nume = $row["nume"];
                    $manager = $row["manager"];
                    $numarAngajati = $row["numarAngajati"];
                } else{
                    // URL doesn't contain valid id. Redirect to error page
                    header("location: error.php");
                    exit();
                }
                
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }
        }
        
        // Close statement
        mysqli_stmt_close($stmt);
        
        // Close connection
        mysqli_close($dbh3);
    }  else{
        // URL doesn't contain id parameter. Redirect to error page
        header("location: error.php");
        exit();
    }
}
?>
 
<!DOCTYPE html>
<html lang="en">
<head>
    <style type="text/css">
        body{

            background-image: url('grey.jpg');
            text-align: center;
            font-family: Georgia, serif;
            
        }

        .box{
            background-color:#909090; 
            position:absolute;
            left:50%;
            top:60%;
            margin-top: 20px;
            transform: translate(-50%,-50%);
            border-radius:10px;
            padding:50px 50px;
        }
        .input-container{
            position:relative;
            margin-bottom:20px;
        }
        .input-container label{
            position:absolute;
            top:0px;
            left:0px;
            font-size:16px;
            color:#000; 
            pointer-events: none;
            transition: all 0.5s ease-in-out;
        }
        .input-container input{ 
          border:0;
          border-bottom:1px solid #f8f8ff;  
          background:transparent;
          width:100%;
          padding:10px 0 10px 0;
          font-size:20px;
          color:#000;
        }
        .input-container input:focus{ 
         border:none;   
         outline:none;
         border-bottom:1px solid #aea0f3;   
        }
        .btn{
            color:#aea0f3;
            background-color:#fff;
            outline: none;
            border: 3px;
            font-weight: bold;
            padding:10px 20px;
            text-transform:uppercase;
            margin-top:50px;
            border-radius:2px;
            cursor:pointer;
            position:relative;
        }
        /*.btn:after{
            content:"";
            position:absolute;
            background:rgba(0,0,0,0.50);
            top:0;
            right:0;
            width:100%;
            height:100%;
        }*/
        .input-container input:focus ~ label,
        .input-container input:valid ~ label{
            top:-16px;
            font-size:16px;
            
        }
        hr{
            color:#aea0f3;
        }

        form{
            margin:auto;
            max-height: 400px;
            max-width: 300px;           
            

        }

        p{
          align-items: center;
          color:#fff;
          font-weight:100;
          font-size:25px;
        }

    </style>
</head>
<body>
  <?php include('templates/header4.php');?>
    
    <section class="container-md">
        <div class="box">
            
                <p>Modifica un departament</p>
                    
                    <form autocomplete="off" action="<?php echo htmlspecialchars(basename($_SERVER['REQUEST_URI'])); ?>" method="post">
                        <div class="input-container <?php echo (!empty($nume_err)) ? 'has-error' : ''; ?>">
                            <input autocomplete="off" type="text" name="nume" value="<?php echo $nume; ?>" placeholder="nume">
                            <div class="input-container"><?php echo $nume_err;?></div>
                        </div>
                        <br>
                        <div class="input-container <?php echo (!empty($manager_err)) ? 'has-error' : ''; ?>">
                            <input autocomplete="off" name="manager" value="<?php echo $manager; ?>" placeholder="manager">
                            <div class="input-container"><?php echo $manager_err;?></div>
                        </div>
                        <br>
                        <div class="input-container <?php echo (!empty($numarAngajati_err)) ? 'has-error' : ''; ?>">      
                            <input autocomplete="off" type="text" name="numarAngajati"  value="<?php echo $numarAngajati; ?>" placeholder="numarAngajati">
                            <div class="input-container"><?php echo $numarAngajati_err;?></div>
                        </div>
                        <input type="hidden" name="id" value="<?php echo $id; ?>"/>
                        <input type="submit" class="btn " value="Submit">
                        <a href="index4.php" class="btn ">Cancel</a>
                    </form>
                </div>
            </div>        
        </div>
    </div>
</body>
</html>
