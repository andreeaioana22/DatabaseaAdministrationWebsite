<html>
	<style>
	body {
  	background-image: url('logo.jpeg');
  	background-repeat: no-repeat;
    background-attachment: fixed;
    background-size: cover;
	}
</style>
	<body>

	</body>
</html>
