<?php

?>
<!DOCTYPE html>
<html lang="en">
<head>
	  <?php include('templates/header5.php');?>
	<style type="text/css">
		* {
			-webkit-transition-property: all;
			-webkit-transition-duration: .2s;
		  -moz-transition-timing-function: cubic-bezier(100,50,21,6);
			-moz-transition-property: all;
		  -moz-transition-timing-function: cubic-bezier(100,50,21,6);
		}

		body{
		    text-align: center;
		  	font-family: Georgia, serif;
		  	background-image: url('grey.jpg');
		}

		p{
		  align-items: center;
		  color:#fff;
		  font-weight:100;
		  font-size:25px;

		}

		.btn{
		  color:#fff;
		  background:rgba(199, 165, 243, 1);
		  padding:10px 20px;
		  font-size:12px;
		  text-decoration:none;
		  letter-spacing:2px;
		  text-transform:uppercase;
		}

		.btn:hover{
		  border:none;
		  background:rgba(0, 0, 0, 0.4);
		  background:#fff;
		  padding:15px 20px; 
		  color:#1b1b1b;
		}

		.footer{
		  font-size:8px;
		  color:#fff;
		  clear:both;
		  display:block;
		  letter-spacing:5px;
		  border:1px solid #fff;
		  padding:5px;
		  text-decoration:none;
		  width:210px;
		  margin:auto;
		  margin-top:400px;
		}		
	</style>
</head>

 <body>
	
	<link href='https://fonts.googleapis.com/css?family=Oswald:300' rel='stylesheet' type='text/css'>
	<p>Alege din urmatoarele tabele: </p>
	<br>
	
    <p>Tabelul client: </p>
    
    <a href="viewclientcons.php" class="btn">Vizualizare</a>
    <a href="addclientcons.php" class="btn">Adaugare</a>
    <a href="modifyclientcons.php" class="btn">Modificare/Stergere</a>
    <!--<a href="deleteclientcluj.php" class="btn">Stergere</a> -->
    <br>
    <br>
    <p>Tabelul produse: </p>
    
    <a href="viewprodcons.php" class="btn">Vizualizare</a>
    <a href="addprodcons.php" class="btn">Adaugare</a>
    <a href="modifyprodcons.php" class="btn">Modificare/Stergere</a>

    <br>
    <br>
    <p>Tabelul angajat: </p>
    
    <a href="viewangcons.php" class="btn">Vizualizare</a>
    <a href="addangcons.php" class="btn">Adaugare</a>
    <a href="modifyangcons.php" class="btn">Modificare/Stergere</a>

    <br>
    <br>
    <p>Tabelul departament: </p>
    
    <a href="viewdepcons.php" class="btn">Vizualizare</a>
    <a href="adddepcons.php" class="btn">Adaugare</a>
    <a href="modifydepcons.php" class="btn">Modificare/Stergere</a>

    <br>
    <br>
    <?php include('templates/footer.php');?>
</body>
  
</html>