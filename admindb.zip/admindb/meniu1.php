<html>
	<head>
		<link rel="stylesheet" type="text/css" href="meniu.css">
	</head>
<body>
	<script src="meniu1.js"></script>


</body>
</html>