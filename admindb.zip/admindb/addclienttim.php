<?php
	
	$servername = "localhost";
	$username = "andreea";
	$password = "test1234";
	$dbname = "timisoara";

	// Create connection
	$dbh3 = new mysqli($servername, $username, $password, $dbname);
	// Check connection
	if ($dbh3->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
	}

	$nume=$prenume=$telefon='';
	
	$errors=array('nume'=>'','prenume'=>'','telefon'=>'');	
	
	if(isset($_POST['submit'])){	

	//check FirstName
	if(empty($_POST['nume'])){
		$errors['nume'] = 'nume trebuie completat!';
	} else{
		$nume = $_POST['nume'];
		//from the start to the end:
		if(!preg_match('/^[a-zA-Z\s]+$/',$nume)){
			$errors['nume'] = 'Numele trebuie sa contina doar litere si spatii';
		}		
	}
	//check LastName
	if(empty($_POST['prenume'])){
		$errors['prenume'] ='prenume trebuie completat!';
	} else{
		$prenume = $_POST['prenume'];
		//frm the start to the end:
		if(!preg_match('/^[a-zA-Z\s]+$/',$prenume)){
			$errors['prenume'] =  'Prenumele trebuie sa contina doar litere si spatii';
		}
	}
	if(empty($_POST['telefon'])){
		$errors['telefon'] ='telefon trebuie completat!';
	} else{
		$telefon=$_POST['telefon'];
		if(!preg_match('/^[+]?[4-4]{1}[0-0]{1}[7-7]{1}[1-9]{8}$/',$telefon)){
			$errors['telefon'] =  'Numarul de telefon trebuie sa contina sintaxa specifica';
		}
	}
	if(array_filter($errors)){
//		echo 'errors in the form';
	} else {
		$nume = mysqli_real_escape_string($dbh3, $_POST['nume']);
		$prenume = mysqli_real_escape_string($dbh3, $_POST['prenume']);
		$telefon = mysqli_real_escape_string($dbh3, $_POST['telefon']);

		//create sql
		$sql= "INSERT INTO clienti(nume,prenume,telefon) VALUES ('$nume','$prenume','$telefon')";


		// save to db and check
		if(mysqli_query($dbh3,$sql)){
			//error
		}else{
			//error
			echo 'query error:' . mysqli_error($dbh3);
		}

//		echo 'no errors';
		header('Location: index4.php');
	}
	
	}// end of POST check
	


?>
<!DOCTYPE html>
<html lang="en">
<head>
	<style type="text/css">

		body{

			background-image: url('grey.jpg');
		    text-align: center;
		  	font-family: Georgia, serif;
		  	
		}

		.box{
			background-color:#909090; 
			position:absolute;
			left:50%;
			top:60%;
			margin-top: 20px;
			transform: translate(-50%,-50%);
		    border-radius:10px;
			padding:50px 50px;
		}
		.input-container{
			position:relative;
			margin-bottom:20px;
		}
		.input-container label{
			position:absolute;
			top:0px;
			left:0px;
			font-size:16px;
			color:#000;	
		    pointer-events: none;
			transition: all 0.5s ease-in-out;
		}
		.input-container input{ 
		  border:0;
		  border-bottom:1px solid #f8f8ff;  
		  background:transparent;
		  width:100%;
		  padding:10px 0 10px 0;
		  font-size:20px;
		  color:#000;
		}
		.input-container input:focus{ 
		 border:none;	
		 outline:none;
		 border-bottom:1px solid #aea0f3;	
		}
		.btn{
			color:#aea0f3;
			background-color:#fff;
			outline: none;
		    border: 3px;
		    font-weight: bold;
			padding:10px 20px;
			text-transform:uppercase;
			margin-top:50px;
			border-radius:2px;
			cursor:pointer;
			position:relative;
		}
		/*.btn:after{
			content:"";
			position:absolute;
			background:rgba(0,0,0,0.50);
			top:0;
			right:0;
			width:100%;
			height:100%;
		}*/
		.input-container input:focus ~ label,
		.input-container input:valid ~ label{
			top:-16px;
			font-size:16px;
			
		}
		hr{
			color:#aea0f3;
		}

		form{
			margin:auto;
			max-height: 400px;
			max-width: 300px;			
			

		}

		p{
		  align-items: center;
		  color:#fff;
		  font-weight:100;
		  font-size:25px;
		}


	</style>
</head>
<body>
  <?php include('templates/header4.php');?>
	
	<section class="container-md">
		<div class="box">
		
		<form autocomplete="off" action="addclienttim.php" method="POST">
			<p>Adauga un client</p>
			<hr class="hr">
			
			<div class="input-container"><input autocomplete="off" type="text" name="nume" value="<?php echo htmlspecialchars($nume) ?>" placeholder="nume"></div>
			<div class="input-container"><?php echo $errors['nume']; ?></div>
			<br>
			<div class="input-container"><input autocomplete="off" type="text" name="prenume" value="<?php echo htmlspecialchars($prenume) ?>" placeholder="prenume"></div>
			<div class="input-container"><?php echo $errors['prenume']; ?></div>
			<br>
			
			<div class="input-container"><input autocomplete="off" type="tel" name="telefon" placeholder="telefon" value="<?php echo htmlspecialchars($telefon) ?>"></div>
			<div class="input-container"><?php echo $errors['telefon']; ?></div>
			
			<table style="width:100%"> </table>
			
			<input type="submit" name="submit" value="submit" class="btn">
			
			
			
		</form>
	</div>
	</section>
	


</body>


</html>
